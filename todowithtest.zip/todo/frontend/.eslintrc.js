module.exports = {
  extends: [
    "plugin:prettier/recommended",
    "prettier",
    "prettier/react",
    "react-app",
    "react-app/jest",
  ],
};
